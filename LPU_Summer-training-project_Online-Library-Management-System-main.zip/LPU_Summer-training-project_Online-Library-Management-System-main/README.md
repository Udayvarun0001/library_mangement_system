This project was completed during the LPU summer training program related to a MySQL course, within the broader domain of Database Management.
Dated: May-July 2024
